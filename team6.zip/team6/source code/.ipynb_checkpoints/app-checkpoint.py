import  numpy as np
import pickle
import streamlit as st
loaded_model = pickle.load(open("trained_model.sav","rb"))
def HDP(input_data):
    
    input_data_as_numpy_array = np.asarray(input_data)
    input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)
    prediction = loaded_model.predict(input_data_reshaped)
    print(prediction)
    if (prediction[0] == 0):
        return 'The person do not have a Heart Disease'
    else :
        return 'The person has a Heart Disease'
import streamlit as st
import numpy as np

# Assuming HDP function is defined elsewhere and imported here.
# from your_module import HDP

def main():
    st.title('Heart Disease Predictor')
    
    # Collect user inputs
    age = st.text_input("Age")
    sex = st.text_input("Gender (1 = Male, 0 = Female)")
    cp = st.text_input("Chest Pain Type")
    trestbps = st.text_input("Resting Blood Pressure")
    chol = st.text_input("Serum Cholesterol in mg/dl")
    fbs = st.text_input("Fasting Blood Sugar (1 = True; 0 = False)")
    restecg = st.text_input("Resting Electrocardiographic Results")
    thalach = st.text_input("Maximum Heart Rate Achieved")
    exang = st.text_input("Exercise Induced Angina (1 = Yes; 0 = No)")
    oldpeak = st.text_input("ST depression induced by exercise")
    slope = st.text_input("Slope of the peak exercise ST segment")
    ca = st.text_input("Major vessels colored by Flourosopy")
    thal = st.text_input("Thalassemia (3 = Normal; 6 = Fixed Defect; 7 = Reversible Defect)")
    
    diagnosis = ""
    
    if st.button('Test Result:'):
        # Convert inputs to a NumPy array and call the HDP function
        try:
            features = np.array([
                float(age), int(sex), int(cp), float(trestbps), float(chol),
                int(fbs), int(restecg), float(thalach), int(exang), 
                float(oldpeak), int(slope), int(ca), int(thal)
            ])
            diagnosis = HDP(features)  # Ensure HDP function is defined to accept this input format
        except ValueError:
            diagnosis = "Please ensure all inputs are valid numbers."
    
    st.success(diagnosis)

if __name__ == '__main__':
    main()
